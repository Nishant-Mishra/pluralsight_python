# __init__.py for 'compressed' subpackage
